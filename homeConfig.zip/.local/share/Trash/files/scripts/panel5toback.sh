#!/bin/bash
panel=$(wmctrl -l)
p=($panel)
wmctrl -i -r ${p[16]} -b add,below
