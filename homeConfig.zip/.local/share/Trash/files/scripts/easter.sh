#!/bin/bash
xterm -e cmatrix
